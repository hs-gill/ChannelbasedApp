const express = require('express');
const router = express.Router();
const replyController = require('./replyController');
module.exports = (upload) => {
// Get all replies to a specific message
router.get('/message/:messageId', replyController.getRepliesByMessage);

// Post a new reply to a message
router.post('/message/:messageId', upload.single('image'), replyController.postReply);


// Update a reply
router.put('/:replyId', replyController.updateReply);

// Delete a reply
router.delete('/:replyId', replyController.deleteReply);

return router;}

const express = require('express');
const router = express.Router();
const messageController = require('./messageController');

module.exports = (upload) => {
    // Get all messages in a channel
    router.get('/channel/:channelId', messageController.getMessagesInChannel);

    // Get a specific message by ID
    router.get('/:messageId', messageController.getMessageById);

    // Create a new message in a channel with image upload
    router.post('/channel/:channelId', upload.single('image'), messageController.postMessage);

    // Update a message
    router.put('/:messageId', messageController.updateMessage);

    // Delete a message
    router.delete('/:messageId', messageController.deleteMessage);

    return router;
};

const express = require('express');
const router = express.Router();
const ratingController = require('./ratingController');

// Rate a message
router.post('/message/:messageId', ratingController.rateMessage);

// Rate a reply
router.post('/reply/:replyId', ratingController.rateReply);
router.get('/:messageId', ratingController.getMessageRating);
router.get('/reply/:replyId', ratingController.getReplyRating);

module.exports = router;

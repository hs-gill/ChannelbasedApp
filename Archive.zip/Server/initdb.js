// init-db.js

const mysql = require('mysql2');
const retryInterval = 5000; // 5 seconds

const connection = mysql.createConnection({
  host: 'db',
  user: 'root',
  password: 'password',
  database: 'ChannelBasedToolDB'
});

function connect() {
  connection.connect(err => {
    if (err) {
      console.error('Failed to connect to MySQL, retrying:', err);
      setTimeout(connect, retryInterval);
    } else {
      console.log('Connected to MySQL');
      process.exit(0); // Exit script successfully
    }
  });
}

connect();

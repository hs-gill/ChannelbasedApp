const mysql = require('mysql');

// Configure MySQL connection
const connection = mysql.createConnection({
    host: 'db',
    user: 'root',           // Replace with your MySQL username
    password: 'password',           // Replace with your MySQL password
});

// Connect to MySQL
connection.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL as id ' + connection.threadId);

    // Create the database
    createDatabase();
});

// Function to create the database
const createDatabase = () => {
    const dbName = 'ChannelBasedToolDB'; // Name your database
    connection.query(`CREATE DATABASE IF NOT EXISTS ${dbName}`, (err) => {
        if (err) throw err;
        console.log(`Database ${dbName} created or already exists.`);
        connection.changeUser({database : dbName}, (err) => {
            if (err) throw err;
            createTables();
        });
    });
};

// Function to create tables
const createTables = () => {
    // SQL to create Users table
    const createUsersTable = `
    CREATE TABLE IF NOT EXISTS Users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL, 
        display_name VARCHAR(255) NOT NULL,
        avatar_url VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    `;

    // SQL to create Channels table
 // SQL to create Channels table with user_id as a foreign key
const createChannelsTable = `
CREATE TABLE IF NOT EXISTS Channels (
    channel_id INT AUTO_INCREMENT PRIMARY KEY,
    channel_name VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    user_id INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) 
);
`;

    // SQL to create Messages table
    const createMessagesTable = `
        CREATE TABLE IF NOT EXISTS Messages (
            message_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            channel_id INT NOT NULL,
            content TEXT NOT NULL,
            screenshot_url VARCHAR(255),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES Users(user_id),
            FOREIGN KEY (channel_id) REFERENCES Channels(channel_id)
        );
    `;

    // SQL to create Replies table
    const createRepliesTable = `
    CREATE TABLE IF NOT EXISTS Replies (
        reply_id INT AUTO_INCREMENT PRIMARY KEY,
        message_id INT NOT NULL,
        user_id INT NOT NULL,
        content TEXT,
        image_url VARCHAR(255), 
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (message_id) REFERENCES Messages(message_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
    );
    `;
    const createNestedRepliesTable = `
    CREATE TABLE IF NOT EXISTS NestedReplies (
        reply_id INT AUTO_INCREMENT PRIMARY KEY,
        message_id INT NOT NULL,
        user_id INT NOT NULL,
        parent_id INT, -- This is NULL for top-level replies, and references reply_id for nested replies
        content TEXT,
        image_url VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (message_id) REFERENCES Messages(message_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (parent_id) REFERENCES Replies(reply_id) ON DELETE CASCADE -- This line establishes the nesting
    );
    `;

    // SQL to create ReplyLikesDislikes table
    const createReplyLikesDislikesTable = `
    CREATE TABLE IF NOT EXISTS ReplyLikesDislikes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        reply_id INT NOT NULL,
        message_id INT NOT NULL,
        is_like BOOLEAN NOT NULL,
        FOREIGN KEY (user_id) REFERENCES Users(user_id),
        FOREIGN KEY (reply_id) REFERENCES Replies(reply_id),
        FOREIGN KEY (message_id) REFERENCES Messages(message_id),
        UNIQUE KEY unique_user_reply (user_id, reply_id)
    );
    `;

    // SQL to create MessageLikesDislikes table
    const createMessageLikesDislikesTable = `
    CREATE TABLE IF NOT EXISTS MessageLikesDislikes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        message_id INT NOT NULL,
        is_like BOOLEAN NOT NULL,
        FOREIGN KEY (user_id) REFERENCES Users(user_id),
        FOREIGN KEY (message_id) REFERENCES Messages(message_id),
        UNIQUE KEY unique_user_message (user_id, message_id)
    );
    `;

    // Execute SQL statements to create tables
    connection.query(createUsersTable, (err) => {
        if (err) throw err;
        console.log("Users table created or already exists.");
    });

    connection.query(createNestedRepliesTable, (err) => {
        if (err) throw err;
        console.log("Nestedreply table created or already exists.");
    });

    connection.query(createChannelsTable, (err) => {
        if (err) throw err;
        console.log("Channels table created or already exists.");
    });

    connection.query(createMessagesTable, (err) => {
        if (err) throw err;
        console.log("Messages table created or already exists.");
    });

    connection.query(createRepliesTable, (err) => {
        if (err) throw err;
        console.log("Replies table created or already exists.");
    });

    connection.query(createReplyLikesDislikesTable, (err) => {
        if (err) throw err;
        console.log("ReplyLikesDislikes table created or already exists.");
    });

    connection.query(createMessageLikesDislikesTable, (err) => {
        if (err) throw err;
        console.log("MessageLikesDislikes table created or already exists.");
    });
};



module.exports = connection;

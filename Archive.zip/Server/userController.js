const db = require('./dbConfig');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const saltRounds = 10; // for bcrypt
const jwtSecret = 'your_jwt_secret'; // replace with a real secret key

exports.registerUser = async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Check if the email already exists in the database
        const checkQuery = 'SELECT * FROM Users WHERE email = ?';
        db.query(checkQuery, [email], async (checkErr, checkResult) => {
            if (checkErr) {
                console.error('Error checking for duplicate email:', checkErr);
                res.status(500).json({ message: 'Server error', error: checkErr });
            } else if (checkResult.length > 0) {
                // Email already exists, return a conflict response
                res.status(409).json({ message: 'Email already in use' });
            } else {
                // Email is unique, proceed with user registration
                const hashedPassword = await bcrypt.hash(password, saltRounds);
                const insertQuery = 'INSERT INTO Users (username, email, password, display_name) VALUES (?, ?, ?, ?)';
                db.query(insertQuery, [username, email, hashedPassword, ''], (err, result) => {
                    if (err) {
                        console.error('Error registering new user:', err);
                        res.status(500).json({ message: 'Error registering new user', error: err });
                    } else {
                        res.status(201).json({ message: 'User registered successfully' });
                    }
                });
            }
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};


exports.loginUser = (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT * FROM Users WHERE username = ?';

    db.query(query, [username], (err, users) => {
        if (err) {
            console.error('Error logging in:', err);
            res.status(500).json({ message: 'Error logging in', error: err });
            return;
        }
        if (users.length === 0) {
            res.status(400).json({ message: 'User not found' });
            return;
        }

        const user = users[0];
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) {
                console.error('Error comparing passwords:', err);
                res.status(500).json({ message: 'Error comparing passwords', error: err });
            } else if (!isMatch) {
                res.status(401).json({ message: 'Invalid credentials' });
            } else {
                const token = jwt.sign({ userId: user.user_id }, jwtSecret, { expiresIn: '1h' });
                res.status(200).json({
                    message: 'Login successful',
                    token,
                    userId: user.user_id, // Send user ID
                    userName: user.username // Send username
                  });
            }
        });
    });
};

exports.getAllUsers = (req, res) => {
    const query = 'SELECT user_id, username, email,display_name FROM Users';
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).json({ message: 'Error retrieving users', error: err });
        } else {
            res.status(200).json(results);
        }
    });
};

exports.getUserById = (req, res) => {
    const query = 'SELECT user_id, username,email ,display_name FROM Users WHERE user_id = ?';
    db.query(query, [req.params.id], (err, results) => {
        if (err) {
            res.status(500).json({ message: 'Error retrieving user', error: err });
        } else if (results.length === 0) {
            res.status(404).json({ message: 'User not found' });
        } else {
            res.status(200).json(results[0]);
        }
    });
};

exports.updateUser = (req, res) => {
    const { username, display_name } = req.body;
    const userId = req.params.id;

    const query = 'UPDATE Users SET username = ?, display_name = ? WHERE user_id = ?';
    db.query(query, [username, display_name, userId], (err, result) => {
        if (err) {
            res.status(500).json({ message: 'Error updating user', error: err });
        } else {
            res.status(200).json({ message: 'User updated successfully' });
        }
    });
};

exports.deleteUser = (req, res) => {
    const userId = req.params.id;

    // Start a transaction
    db.beginTransaction(err => {
        if (err) {
            return res.status(500).json({ message: 'Error starting transaction', error: err });
        }

        // Delete user's replies
        db.query('DELETE FROM Replies WHERE user_id = ?', [userId], (err, result) => {
            if (err) {
                db.rollback(() => {
                    return res.status(500).json({ message: 'Error deleting replies', error: err });
                });
            }

            // Delete user's messages
            db.query('DELETE FROM Messages WHERE user_id = ?', [userId], (err, result) => {
                if (err) {
                    db.rollback(() => {
                        return res.status(500).json({ message: 'Error deleting messages', error: err });
                    });
                }

                // Finally, delete the user
                db.query('DELETE FROM Users WHERE user_id = ?', [userId], (err, result) => {
                    if (err) {
                        db.rollback(() => {
                            return res.status(500).json({ message: 'Error deleting user', error: err });
                        });
                    } else {
                        db.commit(err => {
                            if (err) {
                                db.rollback(() => {
                                    return res.status(500).json({ message: 'Error committing transaction', error: err });
                                });
                            } else {
                                res.status(200).json({ message: 'User and all related data deleted successfully' });
                            }
                        });
                    }
                });
            });
        });
    });
};


exports.getTopUser = (req, res) => {
    const topUserQuery = `
        SELECT u.user_id, u.username, COUNT(m.message_id) AS messageCount
        FROM Users u
        LEFT JOIN Messages m ON u.user_id = m.user_id
        GROUP BY u.user_id
        ORDER BY messageCount DESC
        LIMIT 1
    `;
    
    db.query(topUserQuery, (err, result) => {
        if (err) {
            console.error('Error retrieving top user:', err);
            res.status(500).json({ message: 'Error retrieving top user', error: err });
        } else if (result.length === 0) {
            res.status(404).json({ message: 'Top user not found' });
        } else {
            const topUser = result[0];
            res.status(200).json(topUser);
        }
    });
};




exports.getUserPostCount = (req, res) => {
    const userId = req.params.userId; // Assuming you receive the user's ID as a parameter

    // SQL query to count the user's posts
    const countPostsQuery = 'SELECT COUNT(*) AS postCount FROM Messages WHERE user_id = ?';
    db.query(countPostsQuery, [userId], (err, result) => {
        if (err) {
            console.error('Error counting posts:', err);
            res.status(500).json({ message: 'Error counting posts', error: err });
        } else {
            const postCount = result[0].postCount;
            // console.log(postCount);
            res.status(200).json({ postCount });
        }
  
    });
};


const db = require('./dbConfig');

exports.getMessagesInChannel = (req, res) => {
  const channelId = req.params.channelId;
  const query = `
    SELECT M.*, U.username
    FROM Messages M
    INNER JOIN Users U ON M.user_id = U.user_id
    WHERE M.channel_id = ?
  `;

  db.query(query, [channelId], (err, results) => {
    if (err) {
      console.error("Database query error:", err);
      res.status(500).json({ message: 'Error retrieving messages', error: err });
      return;
    }
    res.status(200).json(results);
  });
};



exports.getMessageById = (req, res) => {
    const messageId = req.params.messageId;
    const query = 'SELECT * FROM Messages WHERE message_id = ?';

    db.query(query, [messageId], (err, results) => {
        if (err) {
            res.status(500).json({ message: 'Error retrieving message', error: err });
        } else if (results.length === 0) {
            res.status(404).json({ message: 'Message not found' });
        } else {
            res.status(200).json(results[0]);
        }
    });
};

exports.postMessage = (req, res) => {
  
    const { channelId, userId, content } = req.body;
    const imageUrl = req.file ? req.file.path : null;

    const query = 'INSERT INTO Messages (channel_id, user_id, content, screenshot_url) VALUES (?, ?, ?, ?)';
    db.query(query, [channelId, userId, content, imageUrl], (err, result) => {
        if (err) {
            res.status(500).json({ message: 'Error posting message', error: err });
        } else {
            res.status(201).json({ message: 'Message posted successfully', messageId: result.insertId });
        }
    });
};

exports.updateMessage = (req, res) => {
    const messageId = req.params.messageId;
    const { content, screenshot_url } = req.body;
    const query = 'UPDATE Messages SET content = ?, screenshot_url = ? WHERE message_id = ?';

    db.query(query, [content, screenshot_url, messageId], (err, result) => {
        if (err) {
            res.status(500).json({ message: 'Error updating message', error: err });
        } else {
            res.status(200).json({ message: 'Message updated successfully' });
        }
    });
};

exports.deleteMessage = (req, res) => {
    const messageId = req.params.messageId;
    const query = 'DELETE FROM Messages WHERE message_id = ?';

    db.query(query, [messageId], (err, result) => {
        if (err) {
            res.status(500).json({ message: 'Error deleting message', error: err });
        } else {
            res.status(200).json({ message: 'Message deleted successfully' });
        }
    });
};

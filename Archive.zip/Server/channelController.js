const db = require('./dbConfig');

exports.getAllChannels = (req, res) => {
    // Modified query to include a JOIN with the Users table
    const query = `
        SELECT Channels.*, Users.username 
        FROM Channels 
        JOIN Users ON Channels.user_id = Users.user_id
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).json({ message: 'Error fetching channels', error: err });
        } else {
            res.status(200).json(results);
        }
    });
};

exports.getChannelById = (req, res) => {
    const query = 'SELECT channel_name, description FROM Channels WHERE channel_id = ?';
    db.query(query, [req.params.id], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if the channel was found
        if (result.length === 0) {
            return res.status(404).send('Channel not found');
        }

        // Respond with the channel details
        const channel = result[0]; // result is an array, so we take the first element
        res.status(200).json({
            name: channel.channel_name,
            description: channel.description
        });
    });
};


exports.createChannel = (req, res) => {
    const { channel_name, description, user_id } = req.body;
    const query = 'INSERT INTO Channels (channel_name, description, user_id) VALUES (?, ?, ?)';

    db.query(query, [channel_name, description, user_id], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).json({ message: 'Error creating channel', error: err });
        } else {
            res.status(201).json({ message: 'Channel created', channelId: result.insertId });
        }
    });
};

exports.updateChannel = (req, res) => {
    const { channel_name, description } = req.body;
    const query = 'UPDATE Channels SET channel_name = ?, description = ? WHERE channel_id = ?';
    db.query(query, [channel_name, description, req.params.id], (err, result) => {
        if (err) throw err;
        res.status(200).json({ message: 'Channel updated' });
    });
};

exports.deleteChannel = (req, res) => {
    const channelId = req.params.id;

    // Start a transaction
    db.beginTransaction(err => {
        if (err) {
            return res.status(500).json({ message: 'Error starting transaction', error: err });
        }

        // First, delete replies related to the channel's messages
        const deleteRepliesQuery = 'DELETE Replies FROM Replies INNER JOIN Messages ON Replies.message_id = Messages.message_id WHERE Messages.channel_id = ?';
        db.query(deleteRepliesQuery, [channelId], (err, result) => {
            if (err) {
                db.rollback(() => {
                    return res.status(500).json({ message: 'Error deleting replies', error: err });
                });
            }

            // Next, delete messages in the channel
            const deleteMessagesQuery = 'DELETE FROM Messages WHERE channel_id = ?';
            db.query(deleteMessagesQuery, [channelId], (err, result) => {
                if (err) {
                    db.rollback(() => {
                        return res.status(500).json({ message: 'Error deleting messages', error: err });
                    });
                }

                // Finally, delete the channel itself
                const deleteChannelQuery = 'DELETE FROM Channels WHERE channel_id = ?';
                db.query(deleteChannelQuery, [channelId], (err, result) => {
                    if (err) {
                        db.rollback(() => {
                            return res.status(500).json({ message: 'Error deleting channel', error: err });
                        });
                    } else {
                        db.commit(err => {
                            if (err) {
                                db.rollback(() => {
                                    return res.status(500).json({ message: 'Error committing transaction', error: err });
                                });
                            } else {
                                res.status(200).json({ message: 'Channel and all related data deleted successfully' });
                            }
                        });
                    }
                });
            });
        });
    });
};

const db = require('./dbConfig');

exports.rateMessage = (req, res) => {
    const messageId = req.params.messageId;
    const { userId, isLike } = req.body;

    // Check if the user has already rated this message
    const checkQuery = 'SELECT * FROM MessageLikesDislikes WHERE user_id = ? AND message_id = ?';
    db.query(checkQuery, [userId, messageId], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Database error', error: err });
        }

        if (results.length > 0) {
            // Update the existing record
            const updateQuery = 'UPDATE MessageLikesDislikes SET is_like = ? WHERE user_id = ? AND message_id = ?';
            db.query(updateQuery, [isLike, userId, messageId], (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Error updating rating', error: err });
                }
                res.status(200).json({ message: 'Rating updated successfully' });
            });
        } else {
            // Insert new rating record
            const insertQuery = 'INSERT INTO MessageLikesDislikes (user_id, message_id, is_like) VALUES (?, ?, ?)';
            db.query(insertQuery, [userId, messageId, isLike], (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Error submitting rating', error: err });
                }
                res.status(201).json({ message: 'Rating submitted successfully' });
            });
        }
    });
};

exports.rateReply = (req, res) => {
    const replyId = req.params.replyId;
    const { userId, isLike, message_id } = req.body;
    // Query to insert or update the like/dislike status
    const upsertQuery = `
        INSERT INTO ReplyLikesDislikes (user_id, reply_id, is_like, message_id) 
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        is_like = VALUES(is_like);
    `;

    db.query(upsertQuery, [userId, replyId, isLike, message_id], (err, result) => {
        if (err) {
            console.error("Error in rateReply:", err);
            return res.status(500).json({ message: 'Error handling rating', error: err });
        }
        res.status(200).json({ message: 'Rating handled successfully' });
    });
};


exports.getMessageRating = (req, res) => {
    const messageId = req.params.messageId;

    const query = `
        SELECT 
            (SELECT COUNT(*) FROM MessageLikesDislikes WHERE message_id = ? AND is_like = 1) AS likes,
            (SELECT COUNT(*) FROM MessageLikesDislikes WHERE message_id = ? AND is_like = 0) AS dislikes
        FROM Messages
        WHERE message_id = ?;
    `;

    db.query(query, [messageId, messageId, messageId], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ message: 'Error retrieving message rating', error: err });
        }

        if (results.length > 0) {
            res.status(200).json({ likes: results[0].likes, dislikes: results[0].dislikes });
        } else {
            res.status(404).json({ message: 'Message not found' });
        }
    });
};

exports.getReplyRating = (req, res) => {
    const replyId = req.params.replyId;
    const messageId = req.query.messageId;

    const query = `
        SELECT 
            (SELECT COUNT(*) FROM ReplyLikesDislikes WHERE reply_id = ? AND message_id = ? AND is_like = 1) AS likes,
            (SELECT COUNT(*) FROM ReplyLikesDislikes WHERE reply_id = ? AND message_id = ? AND is_like = 0) AS dislikes
        FROM Replies
        WHERE reply_id = ? AND message_id = ?;
    `;

    db.query(query, [replyId, messageId, replyId, messageId, replyId, messageId], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ message: 'Error retrieving reply rating', error: err });
        }

        if (results.length > 0) {
            res.status(200).json({ likes: results[0].likes, dislikes: results[0].dislikes });
        } else {
            res.status(404).json({ message: 'Reply not found or no ratings available' });
        }
    });
};


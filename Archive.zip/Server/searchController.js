const db = require('./dbConfig');

// Search content by specific string
exports.searchContent = (req, res) => {
    const searchString = req.query.q;
    const query = `
        SELECT Messages.*, Users.username 
        FROM Messages 
        JOIN Users ON Messages.user_id = Users.user_id 
        WHERE Messages.content LIKE ?`;

    db.query(query, [`%${searchString}%`], (err, results) => {
        if (err) return res.status(500).json({ message: 'Error searching content', error: err });
        res.status(200).json(results);
    });
};


// Search content created by a specific user
exports.searchContentByUser = (req, res) => {
    const username = req.params.username; // Expecting username as a parameter
    const query = `
        SELECT Messages.*, Users.username 
        FROM Messages 
        JOIN Users ON Messages.user_id = Users.user_id 
        WHERE Users.username = ?`;

    db.query(query, [username], (err, results) => {
        if (err) return res.status(500).json({ message: 'Error searching user content', error: err });
        res.status(200).json(results);
    });
};



// Get user with the most/least posts
exports.userWithMostOrLeastPosts = (req, res) => {
    const type = req.query.type; // 'most' or 'least'
    const order = type === 'most' ? 'DESC' : 'ASC';
    const query = `
        SELECT user_id, COUNT(*) as post_count FROM Messages 
        GROUP BY user_id 
        ORDER BY post_count ${order} 
        LIMIT 1
    `;

    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ message: 'Error finding user with most/least posts', error: err });
        res.status(200).json(results[0]);
    });
};

// Get user with the highest/lowest message/reply ranking
exports.userWithHighestOrLowestRanking = (req, res) => {
    const type = req.query.type; // 'highest' or 'lowest'
    // This example assumes 'ranking' is determined by the sum of likes on a user's messages and replies
    const order = type === 'highest' ? 'DESC' : 'ASC';
    const query = `
        SELECT u.user_id, (IFNULL(SUM(m.likes_count), 0) + IFNULL(SUM(r.likes_count), 0)) as total_likes
        FROM Users u
        LEFT JOIN Messages m ON u.user_id = m.user_id
        LEFT JOIN Replies r ON u.user_id = r.user_id
        GROUP BY u.user_id
        ORDER BY total_likes ${order}
        LIMIT 1
    `;

    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ message: 'Error finding user with highest/lowest ranking', error: err });
        res.status(200).json(results[0]);
    });
};
exports.messagesByHighestLikes = (req, res) => {
    const query = `
        SELECT Messages.*, Users.username, 
               COUNT(MessageLikesDislikes.is_like) AS like_count
        FROM Messages 
        JOIN Users ON Messages.user_id = Users.user_id
        LEFT JOIN MessageLikesDislikes ON Messages.message_id = MessageLikesDislikes.message_id
        WHERE MessageLikesDislikes.is_like = TRUE
        GROUP BY Messages.message_id
        ORDER BY like_count DESC`;

    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ message: 'Error retrieving messages', error: err });
        res.status(200).json(results);
    });
};




// New controller function for lowest likes
exports.messagesByLowestLikes = (req, res) => {
    const query = `
        SELECT Messages.*, Users.username, 
               COALESCE(SUM(CASE WHEN MessageLikesDislikes.is_like = 1 THEN 1 ELSE 0 END), 0) AS like_count,
               COALESCE(SUM(CASE WHEN MessageLikesDislikes.is_like = 0 THEN 1 ELSE 0 END), 0) AS dislike_count
        FROM Messages 
        JOIN Users ON Messages.user_id = Users.user_id
        LEFT JOIN MessageLikesDislikes ON Messages.message_id = MessageLikesDislikes.message_id
        GROUP BY Messages.message_id, Users.username
        ORDER BY dislike_count DESC, like_count ASC`;

    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error retrieving messages', error: err });
        }
        res.status(200).json(results);
    });
};



const db = require('./dbConfig');

exports.getRepliesByMessage = (req, res) => {
    const messageId = req.params.messageId;
    const query = `
        SELECT R.*, U.username
        FROM Replies R
        INNER JOIN Users U ON R.user_id = U.user_id
        WHERE R.message_id = ?
    `;

    db.query(query, [messageId], (err, results) => {
        if (err) {
            res.status(500).json({ message: 'Error retrieving replies', error: err });
        } else {
            res.status(200).json(results);
        }
    });
};

exports.postReply = (req, res) => {
    const messageId = req.params.messageId;
    const { userId, content } = req.body;
    const imageUrl = req.file ? req.file.path : null;

    const query = 'INSERT INTO Replies (message_id, user_id, content, image_url) VALUES (?, ?, ?, ?)';
    db.query(query, [messageId, userId, content, imageUrl], (err, result) => {
        if (err) {
            res.status(500).json({ message: 'Error posting reply', error: err });
        } else {
            res.status(201).json({ message: 'Reply posted successfully', replyId: result.insertId });
        }
    });
};

exports.updateReply = (req, res) => {
    const replyId = req.params.replyId;
    const { content } = req.body;
    const query = 'UPDATE Replies SET content = ? WHERE reply_id = ?';

    db.query(query, [content, replyId], (err, result) => {
        if (err) {
            res.status(500).json({ message: 'Error updating reply', error: err });
        } else {
            res.status(200).json({ message: 'Reply updated successfully' });
        }
    });
};
exports.deleteReply = (req, res) => {
    const replyId = req.params.replyId;
    const messageId = req.body.message_id; // Ensure this matches the case from the frontend

    console.log(`Received DELETE request for replyId: ${replyId}, messageId: ${messageId}`);

    // Delete records from ReplyLikesDislikes table associated with the replyId and messageId
    const deleteLikesDislikesQuery = 'DELETE FROM ReplyLikesDislikes WHERE reply_id = ? AND message_id = ?';

    // Pass both replyId and messageId to the query
    db.query(deleteLikesDislikesQuery, [replyId, messageId], (likesDislikesErr) => {
        if (likesDislikesErr) {
            console.error('Error deleting likes and dislikes:', likesDislikesErr);
            res.status(500).json({ message: 'Error deleting likes and dislikes', error: likesDislikesErr });
        } else {
            // After successfully deleting likes and dislikes, delete the reply
            const deleteReplyQuery = 'DELETE FROM Replies WHERE reply_id = ? AND message_id = ?';

            // Pass both replyId and messageId to the query
            db.query(deleteReplyQuery, [replyId, messageId], (err, result) => {
                if (err) {
                    console.error('Error deleting reply:', err);
                    res.status(500).json({ message: 'Error deleting reply', error: err });
                } else if (result.affectedRows === 0) {
                    console.error('Reply not found with the provided ids');
                    res.status(404).json({ message: 'Reply not found with the provided ids' });
                } else {
                    console.log('Reply and associated likes/dislikes deleted successfully');
                    res.status(200).json({ message: 'Reply deleted successfully' });
                }
            });
        }
    });
};



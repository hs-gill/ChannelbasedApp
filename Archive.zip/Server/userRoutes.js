const express = require('express');
const router = express.Router();
const userController = require('./userController');

// Register a new user
router.post('/register', userController.registerUser);

// User login
router.post('/signin', userController.loginUser);

// Get all users
router.get('/', userController.getAllUsers);

// Get a specific user by ID
router.get('/:id', userController.getUserById);

// Update a user
router.put('/:id', userController.updateUser);

// Delete a user
router.delete('/:id', userController.deleteUser);

router.get('/postCount/:userId', userController.getUserPostCount);




module.exports = router;

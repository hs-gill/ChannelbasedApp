const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const mysql = require('mysql2');

// Routes
const userRoutes = require('./userRoutes');
const channelRoutes = require('./channelRoutes');
const messageRoutes = require('./messageRoutes');
const replyRoutes = require('./replyRoutes');
const ratingRoutes = require('./ratingRoutes');
const searchRoutes = require('./searchRoutes');
const topUserRoutes = require('./topuserRoutes');

const app = express();

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'uploads/'); // Ensure this directory exists
    },
    filename: function(req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve files from uploads directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Apply routes
app.use('/api/users', userRoutes);
app.use('/api/channels', channelRoutes);
app.use('/api/messages', messageRoutes(upload));
app.use('/api/replies', replyRoutes(upload));
app.use('/api/rating', ratingRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/top', topUserRoutes);

// MySQL Connection Configuration
const dbConnection = mysql.createConnection({
    host: 'db', // Name of your database service in Docker Compose
    user: 'root',           // Replace with your MySQL username
    password: 'password',   // Replace with your MySQL password
    // multipleStatements: true
});

// Connect to MySQL and Initialize Database and Tables
dbConnection.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL as id ' + dbConnection.threadId);
    initializeDatabase();
});

// Initialize Database and Tables
const initializeDatabase = () => {
    const dbName = 'ChannelBasedToolDB'; // Name your database
    dbConnection.query(`CREATE DATABASE IF NOT EXISTS ${dbName}`, (err) => {
        if (err) throw err;
        console.log(`Database ${dbName} created or already exists.`);
        dbConnection.changeUser({database : dbName}, (err) => {
            if (err) throw err;
            createTables();
        });
    });
};

// Function to create tables
const createTables = () => {
    // SQL to create Users table
    const createUsersTable = `
    CREATE TABLE IF NOT EXISTS Users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL, 
        display_name VARCHAR(255) NOT NULL,
        avatar_url VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    `;

    // SQL to create Channels table
 // SQL to create Channels table with user_id as a foreign key
const createChannelsTable = `
CREATE TABLE IF NOT EXISTS Channels (
    channel_id INT AUTO_INCREMENT PRIMARY KEY,
    channel_name VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    user_id INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) 
);
`;

    // SQL to create Messages table
    const createMessagesTable = `
        CREATE TABLE IF NOT EXISTS Messages (
            message_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            channel_id INT NOT NULL,
            content TEXT NOT NULL,
            screenshot_url VARCHAR(255),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES Users(user_id),
            FOREIGN KEY (channel_id) REFERENCES Channels(channel_id)
        );
    `;

    // SQL to create Replies table
    const createRepliesTable = `
    CREATE TABLE IF NOT EXISTS Replies (
        reply_id INT AUTO_INCREMENT PRIMARY KEY,
        message_id INT NOT NULL,
        user_id INT NOT NULL,
        content TEXT,
        image_url VARCHAR(255), 
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (message_id) REFERENCES Messages(message_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
    );
    `;
  

    // SQL to create ReplyLikesDislikes table
    const createReplyLikesDislikesTable = `
    CREATE TABLE IF NOT EXISTS ReplyLikesDislikes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        reply_id INT NOT NULL,
        message_id INT NOT NULL,
        is_like BOOLEAN NOT NULL,
        FOREIGN KEY (user_id) REFERENCES Users(user_id),
        FOREIGN KEY (reply_id) REFERENCES Replies(reply_id),
        FOREIGN KEY (message_id) REFERENCES Messages(message_id),
        UNIQUE KEY unique_user_reply (user_id, reply_id)
    );
    `;

    // SQL to create MessageLikesDislikes table
    const createMessageLikesDislikesTable = `
    CREATE TABLE IF NOT EXISTS MessageLikesDislikes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        message_id INT NOT NULL,
        is_like BOOLEAN NOT NULL,
        FOREIGN KEY (user_id) REFERENCES Users(user_id),
        FOREIGN KEY (message_id) REFERENCES Messages(message_id),
        UNIQUE KEY unique_user_message (user_id, message_id)
    );
    `;

    // Execute SQL statements to create tables
    dbConnection.query(createUsersTable, (err) => {
        if (err) throw err;
        console.log("Users table created or already exists.");
    });

    dbConnection.query(createChannelsTable, (err) => {
        if (err) throw err;
        console.log("Channels table created or already exists.");
    });

    dbConnection.query(createMessagesTable, (err) => {
        if (err) throw err;
        console.log("Messages table created or already exists.");
    });

    dbConnection.query(createRepliesTable, (err) => {
        if (err) throw err;
        console.log("Replies table created or already exists.");
    });

    dbConnection.query(createReplyLikesDislikesTable, (err) => {
        if (err) throw err;
        console.log("ReplyLikesDislikes table created or already exists.");
    });

    dbConnection.query(createMessageLikesDislikesTable, (err) => {
        if (err) throw err;
        console.log("MessageLikesDislikes table created or already exists.");
    });

};

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

module.exports = { upload, dbConnection }; // Export multer upload and MySQL connection for use in routes

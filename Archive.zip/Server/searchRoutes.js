


const express = require('express');
const router = express.Router();
const searchController = require('./searchController');

// Existing routes
router.get('/content', searchController.searchContent);
// Search content created by a specific user
router.get('/content/user/:username', searchController.searchContentByUser);
router.get('/user/posts', searchController.userWithMostOrLeastPosts);
router.get('/user/ranking', searchController.userWithHighestOrLowestRanking);

// New routes for searching by likes
router.get('/messages/highestLikes', searchController.messagesByHighestLikes);
router.get('/messages/lowestLikes', searchController.messagesByLowestLikes);

module.exports = router;


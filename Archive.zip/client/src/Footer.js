import React from 'react';
import './Global.css'; 

const Footer = () => {
  return (
    <footer className="global-footer">
      <p>© 2023 Programming Questionnaire App</p>
    </footer>
  );
};

export default Footer;

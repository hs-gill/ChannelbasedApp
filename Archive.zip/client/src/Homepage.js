import React from 'react';
import { Link } from 'react-router-dom';
import './Global.css'; // Ensure the path to your Global.css is correct

const HomePage = () => {
  return (
    <div class="d-flex flex-column justify-content-center w-100 h-100">

	<div class="d-flex flex-column justify-content-center align-items-center">

		<div class="btn-group my-5">

    <div className="home-page-container">
      <div className="home-page-content">
        <h1 className="home-page-heading">Welcome to CodeConnect</h1>
        <p className="home-page-text">
          CodeConnect is a tech-based messaging platform designed for developers and tech enthusiasts. Connect, collaborate, and share your coding experiences!
        </p>
        <ul className="home-page-list">
    
          <li>Explore coding channels across various technologies.</li>
          <li>Engage in discussions, share code snippets, and get programming help.</li>
          <li>Stay updated with the latest tech trends and updates in the developer community.</li>
          <li>Network with like-minded tech enthusiasts.</li>
          
        </ul>
        <div>
          <Link to="/signin" className="button sign-in-btn">Sign In</Link>
          <Link to="/register" className="button register-btn">Register</Link>
        </div>
      </div>
    </div>
   

		</div>


		
	</div>
</div>


  );
};

export default HomePage;

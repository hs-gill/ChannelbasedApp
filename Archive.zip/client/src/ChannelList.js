import React, { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from './AuthContext';
import './Global.css';

const ChannelListComponent = ({ channels, onChannelsUpdated }) => {
    const { userName } = useContext(AuthContext);
    const [searchTerm, setSearchTerm] = useState('');

    const handleDelete = async (channelId) => {
        if (window.confirm("Are you sure you want to delete this channel?")) {
            try {
                const response = await fetch(`http://localhost:3001/api/channels/${channelId}`, {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                });

                if (!response.ok) throw new Error('Failed to delete the channel');
                onChannelsUpdated(); // Assuming this function re-fetches the channel list
            } catch (error) {
                console.error('Error deleting channel:', error);
            }
        }
    };

    const canDelete = userName === 'Harpreet' || userName === 'harpreet';

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value.toLowerCase());
    };

    const filteredChannels = channels.filter(channel =>
        channel.channel_name.toLowerCase().includes(searchTerm) ||
        channel.description.toLowerCase().includes(searchTerm)
    );

    return (
        <div className="channel-container">
            <h2 className="channel-heading">Channels</h2>
            <div className="relative mb-4">
                <input
                    type="text"
                    placeholder="Search Channels"
                    value={searchTerm}
                    onChange={handleSearchChange}
                    className="channel-search-input"
                />
            </div>
            <ul>
                {filteredChannels.map(channel => (
                    <li key={channel.channel_id} className="channel-list-item">
                        <div>
                            <Link to={`/channels/${channel.channel_id}/messages`} className="channel-link">
                                {channel.channel_name}
                            </Link>
                            <p className="channel-description">{channel.description}</p>
                            <p className="channel-author">Created by {channel.username}</p>
                        </div>
                        {canDelete && (
                            <button 
                                onClick={() => handleDelete(channel.channel_id)}
                                className="channel-delete-button"
                            >
                                Delete
                            </button>
                        )}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ChannelListComponent;

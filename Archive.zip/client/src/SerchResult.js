import React from 'react';
import MessageItem from './MessageItem';
import './Global.css';

const SearchResults = ({ results }) => {
  // Function to delete a message - Placeholder for actual implementation
  const handleDeleteMessage = (messageId) => {
    console.log('Delete message', messageId);
  };

  // Function to handle reply post - Placeholder for actual implementation
  const handlePostReply = (messageId, formData) => {
    console.log('Post reply for message', messageId);
    // Implement reply posting logic here
  };

  return (
    <div className="search-results-container">
      {results.length > 0 ? (
        results.map((item) => (
          <MessageItem 
            key={item.message_id}
            message={item}
            onDelete={handleDeleteMessage}
            onPostReply={handlePostReply}
          />
        ))
      ) : (
        <p className="search-results-message">No results found.</p>
      )}
    </div>
  );
};

export default SearchResults;
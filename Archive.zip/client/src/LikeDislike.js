// LikeDislike.js
import React from 'react';

const LikeDislike = ({ likes, dislikes, onLike, onDislike }) => {
  return (
    <div className="flex items-center">
      <button onClick={onLike} className="mr-2">👍 {likes}</button>
      <button onClick={onDislike}>👎 {dislikes}</button>
    </div>
  );
};

export default LikeDislike;

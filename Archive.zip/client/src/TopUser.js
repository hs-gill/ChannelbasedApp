import React, { useState, useEffect } from 'react';
import './Global.css'; // Import the global CSS file

const TopUser = () => {
  const [topUser, setTopUser] = useState(null);

  useEffect(() => {
    const fetchTopUser = async () => {
      try {
        const response = await fetch('http://localhost:3001/api/top');
        if (!response.ok) {
          throw new Error('Failed to fetch top user');
        }
        const data = await response.json();
        setTopUser(data);
      } catch (error) {
        console.error('Error fetching top user:', error);
      }
    };

    fetchTopUser();
  }, []);

  return (
    <div className="top-user-container">
      {topUser ? (
        <p>Star user of the app: {topUser.username}</p>
      ) : (
        <p>Loading top user...</p>
      )}
    </div>
  );
};

export default TopUser;

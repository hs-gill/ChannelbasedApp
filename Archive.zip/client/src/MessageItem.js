

import React, { useState, useContext, useEffect,useCallback } from 'react';
import { AuthContext } from './AuthContext';
import ReplyListComponent from './ReplyList';
import NewReplyComponent from './NewReply';
import './Global.css'; 

const MessageItem = ({ message, onDelete }) => {
    const [showReplies, setShowReplies] = useState(false);
    const [replies, setReplies] = useState([]);
    const [likes, setLikes] = useState(message.likes || 0); // Initialize likes from message data
    const [dislikes, setDislikes] = useState(message.dislikes || 0); // Initialize dislikes from message data
    const { userId, userName} = useContext(AuthContext);

  

    const fetchLikesDislikes = useCallback(async () => {
      try {
          const response = await fetch(`http://localhost:3001/api/rating/${message.message_id}`);
          if (!response.ok) throw new Error('Failed to fetch rating');
          const { likes, dislikes } = await response.json();
          setLikes(likes);
          setDislikes(dislikes);
      } catch (error) {
          console.error('Error fetching rating:', error);
      }
  }, [message.message_id]); // Dependency for useCallback

  useEffect(() => {
    fetchLikesDislikes();
    if (showReplies) {
        fetchReplies(message.message_id);
    }
}, [showReplies, message.message_id, fetchLikesDislikes]);

const updateRating = async (isLike) => {
    try {
        const response = await fetch(`http://localhost:3001/api/rating/message/${message.message_id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, isLike })
        });
        if (!response.ok) throw new Error('Failed to update rating');
        fetchLikesDislikes(); // Refetch rating after update
    } catch (error) {
        console.error('Error updating rating:', error);
    }
};

const handleLike = () => {
    setLikes(likes + 1); // Optimistic update
    updateRating(true);
};

const handleDislike = () => {
    setDislikes(dislikes + 1); // Optimistic update
    updateRating(false);
};


  const handleToggleReplies = () => {
    setShowReplies(!showReplies);
  };

  const fetchReplies = async (messageId) => {
    try {
      const response = await fetch(`http://localhost:3001/api/replies/message/${messageId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch replies');
      }
      const repliesData = await response.json();
      setReplies(repliesData);
    } catch (error) {
      console.error('Error fetching replies:', error);
    }
  };

  const handlePostReply = async (messageId, formData) => {
    try {
      const response = await fetch(`http://localhost:3001/api/replies/message/${messageId}`, {
        method: 'POST',
        body: formData // Send formData directly
      });
  
      if (!response.ok) {
        throw new Error('Failed to post reply');
      }
  
      fetchReplies(messageId); // Refetch replies to update UI
    } catch (error) {
      console.error('Error posting reply:', error);
    }
  };


  
  

  const handleDeleteMessage = async () => {
    if (window.confirm("Are you sure you want to delete this message?")) {
      try {
        const response = await fetch(`http://localhost:3001/api/messages/${message.message_id}`, {
          method: 'DELETE',
        });

        if (!response.ok) {
          throw new Error('Failed to delete the message');
        }

        onDelete(message.message_id);
      } catch (error) {
        console.error('Error deleting message:', error);
      }
    }
  };
  const handleDeleteReply = async (replyId, messageId) => {
    if (window.confirm("Are you sure you want to delete this reply?")) {
      try {
        const response = await fetch(`http://localhost:3001/api/replies/${replyId}`, {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message_id: messageId }), // Include the message_id in the request body
        });
  
        if (!response.ok) {
          throw new Error('Failed to delete reply');
        }
  
        // Update the replies state to remove the deleted reply
        setReplies(replies.filter(reply => reply.reply_id !== replyId));
      } catch (error) {
        console.error('Error deleting reply:', error);
      }
    }
  };
  

  const canDelete =( userName === 'Harpreet'|| userName === 'harpreet' );

  
  return (
    <div className="message-item-container">
        <div className="message-item-box">
            <strong className="message-item-author">{message.username}: </strong>
            <p className="message-item-content">{message.content}</p>
            {message.screenshot_url && (
                <img src={`http://localhost:3001/${message.screenshot_url}`} alt="Message" className="message-item-img" />
            )}
            <div className="message-item-actions">
                <button onClick={handleLike} className="message-item-button">👍 {likes}</button>
                <button onClick={handleDislike} className="message-item-button">👎 {dislikes}</button>
                <button onClick={handleToggleReplies} className="message-item-button">View Replies</button>
                {canDelete && (
                    <button onClick={() => handleDeleteMessage()} className="message-item-button">Delete Message</button>
                )}
            </div>
        </div>

        {showReplies && (
            <div className="message-item-reply-section">
                
                <ReplyListComponent replies={replies} onDeleteReply={handleDeleteReply} />
                <NewReplyComponent messageId={message.message_id} onPostReply={handlePostReply} />
            </div>
        )}
    </div>
);
};

export default MessageItem;
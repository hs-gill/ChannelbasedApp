import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';


const AllUsers = () => {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    // Fetch all users from the API
    fetch('http://localhost:3001/api/users')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to fetch users');
        }
        return response.json();
      })
      .then((data) => {
        setUsers(data);
      })
      .catch((error) => {
        setError(error.message);
      });
  }, []);

  const handleRemoveUser = (userId) => {
    const confirmRemove = window.confirm('Are you sure you want to remove this user?');
    if (confirmRemove) {
      // Send a request to remove the user by ID to the API
      fetch(`http://localhost:3001/api/users/${userId}`, {
        method: 'DELETE',
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error('Failed to remove user');
          }
          // If the user is successfully removed, update the list of users
          setUsers((prevUsers) => prevUsers.filter((user) => user.user_id !== userId));
        })
        .catch((error) => {
          setError(error.message);
        });
    }
  };

  const handleClosePage = () => {
    // Close the page and navigate back to the previous page
    navigate(-1);
  };
  return (
    <div className="all-users-container">
      <h1 className="all-users-header">User Management</h1>
      {error && <p className="all-users-error">{error}</p>}
      <div className="all-users-table-container">
        <table className="all-users-table">
          <thead className="all-users-thead">
            <tr>
              <th className="all-users-th">Username</th>
              <th className="all-users-th">Email</th>
              <th className="all-users-th">Actions</th>
            </tr>
          </thead>
          <tbody className="all-users-tbody">
            {users.map((user) => (
              <tr key={user.user_id} className="all-users-tbody-tr">
                <td className="all-users-td">{user.username}</td>
                <td className="all-users-td">{user.email}</td>
                <td className="all-users-td text-right">
                  {user.username !== "Harpreet" && (
                    <button
                      onClick={() => handleRemoveUser(user.user_id)}
                      className="all-users-remove-btn"
                    >
                      Remove
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="all-users-footer">
        <button onClick={handleClosePage} className="all-users-close-btn">
          Close
        </button>
      </div>
    </div>
  );
};

export default AllUsers;
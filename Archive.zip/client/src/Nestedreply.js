import React, { useState, useContext } from 'react';
import { AuthContext } from './AuthContext';
import './Global.css';

const NewNestedReply = ({ messageId, parentReplyId, onPostNestedReply }) => {
  const { userId } = useContext(AuthContext);
  const [nestedReply, setNestedReply] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = {
      content: nestedReply,
      userId,
      parentReplyId,
    };

    onPostNestedReply(messageId, formData);

    setNestedReply('');
  };

  return (
    <form onSubmit={handleSubmit} className="reply-item-box"> {/* Use the same class name as ReplyItem */}
      <textarea
        value={nestedReply}
        onChange={(e) => setNestedReply(e.target.value)}
        placeholder="Write your nested reply..."
        required
        rows="3"
        className="reply-item-content" // Use the same class name as ReplyItem
      ></textarea>
      <button type="submit" className="reply-item-button"> {/* Use the same class name as ReplyItem */}
        Post Nested Reply
      </button>
    </form>
  );
};

export default NewNestedReply;

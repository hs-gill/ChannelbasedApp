import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import './Global.css'; // Assuming Global.css is in the same directory

const Layout = ({ children }) => {
  return (
    <div className="global-layout">
      <Navbar />
      <main className="global-layout-main">{children}</main>
      <Footer />
    </div>
  );
};

export default Layout;

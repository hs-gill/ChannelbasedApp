import React, { useState, useContext } from 'react';
import { AuthContext } from './AuthContext'; // Adjust the path to where AuthContext is located

const CreateChannel = ({ onChannelCreated }) => {
  const [channelData, setChannelData] = useState({
    channel_name: '',
    description: ''
  });
  const { userId } = useContext(AuthContext);

  const handleChange = (e) => {
    setChannelData({ ...channelData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:3001/api/channels/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...channelData, user_id: userId })
      });

      if (!response.ok) {
        throw new Error('Error creating channel');
      }

      setChannelData({ channel_name: '', description: '' });
      onChannelCreated();
    } catch (error) {
      console.error('Channel creation failed:', error);
    }
  };

  return (
    <div className="create-channel-wrapper">
      <h2 className="create-channel-title">Create New Channel</h2>
      <form onSubmit={handleSubmit} className="create-channel-form">
        <div className="create-channel-field">
          <label htmlFor="channel_name" className="create-channel-label">Channel Name</label>
          <input
            type="text"
            id="channel_name"
            name="channel_name"
            value={channelData.channel_name}
            onChange={handleChange}
            className="create-channel-input"
            required
          />
        </div>
        <div className="create-channel-field">
          <label htmlFor="description" className="create-channel-label">Description</label>
          <textarea
            id="description"
            name="description"
            value={channelData.description}
            onChange={handleChange}
            className="create-channel-textarea"
            required
          ></textarea>
        </div>
        <button type="submit" className="create-channel-submit">
          Create Channel
        </button>
      </form>
    </div>
  );
};

export default CreateChannel;

import React, { useState, useEffect } from 'react';
import Layout from './Layout';
import ChannelListComponent from './ChannelList';
import CreateChannel from './CreateChannel';
import './Global.css';

const ChannelsPage = () => {
  const [channels, setChannels] = useState([]);

  // Function to fetch channels from the backend
  const fetchChannels = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/channels');
      if (!response.ok) {
        throw new Error('Failed to fetch channels');
      }
      const data = await response.json();
      setChannels(data);
    } catch (error) {
      console.error('Failed to fetch channels:', error);
    }
  };

  // Effect to fetch channels on component mount
  useEffect(() => {
    fetchChannels();
  }, []);

  return (
    <Layout>
      <div className="channels-page-container">
        <div className="channels-page-layout">
          {/* Left Side - Create Channel */}
          <div className="channels-page-create-channel">
            <CreateChannel onChannelCreated={fetchChannels} />
          </div>
          {/* Right Side - Channel List */}
          <div className="channels-page-channel-list">
            <h1 className="channels-page-header">Channels</h1>
            <ChannelListComponent channels={channels} onChannelsUpdated={fetchChannels} />
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ChannelsPage;
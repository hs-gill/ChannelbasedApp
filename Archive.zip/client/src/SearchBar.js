import React, { useState } from 'react';
import './Global.css'; // Assuming Global.css is in the same directory

const SearchBar = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('content');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch(searchTerm, searchType);
  };

  const isTextInputRequired = searchType === 'content' || searchType === 'user';

  return (
    <form onSubmit={handleSubmit} className="search-bar-form">
      {isTextInputRequired && (
        <input 
          type="text" 
          value={searchTerm} 
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search..."
          className="search-bar-input"
        />
      )}
      <select 
        value={searchType} 
        onChange={(e) => setSearchType(e.target.value)} 
        className="search-bar-select"
      >
        <option value="content">Content</option>
        <option value="user">User</option>
        <option value="highestLikes">Highest Rating</option>
        <option value="lowestLikes">Lowest Rating</option>
      </select>
      <button type="submit" className="search-bar-button">
        Search
      </button>
    </form>
  );
};

export default SearchBar;

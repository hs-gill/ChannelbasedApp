import React, { useContext, useEffect, useState } from 'react';
import Layout from './Layout';
import { AuthContext } from './AuthContext';
import { useNavigate } from 'react-router-dom';
import './Global.css';

const UserProfilePage = () => {
  const { userId } = useContext(AuthContext);
  const [userData, setUserData] = useState({
    username: '',
    email: '',
  });
  const [userLevel, setUserLevel] = useState(''); // To store the user's level

  const navigate = useNavigate();

  useEffect(() => {
    // Fetch user data based on the userId or userName using your API
    const fetchUserData = async () => {
      try {
        const response = await fetch(`http://localhost:3001/api/users/${userId}`, {
          method: 'GET',
          headers: {
            // Add your headers here if needed
          },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch user data');
        }

        const userData = await response.json();
        setUserData(userData);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    // Call the fetchUserData function
    if (userId) {
      fetchUserData();
    }
  }, [userId]);

  useEffect(() => {
    // Fetch the user's post count and determine their level
    const fetchUserLevel = async () => {
      try {
        const postCount = await fetchUserPostCount(userId);
        
        // Determine the user's level based on post count
        if (postCount >= 15) {
          setUserLevel('Expert');
        } else if (postCount >= 8) {
          setUserLevel('Intermediate');
        } else {
          setUserLevel('Beginner');
        }
      } catch (error) {
        console.error('Error fetching user level:', error);
      }
    };

    // Call the fetchUserLevel function
    if (userId) {
      fetchUserLevel();
    }
  }, [userId]);

  const handleCloseProfile = () => {
    // Navigate back to the previous page
    navigate(-1);
  };

  const fetchUserPostCount = async (userId) => {
    try {
      const response = await fetch(`http://localhost:3001/api/users/postCount/${userId}`, {
        method: 'GET', // Use GET method
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (!response.ok) {
        throw new Error('Failed to fetch user post count');
      }
  
      const data = await response.json();
      return data.postCount;
    } catch (error) {
      console.error('Error fetching user post count:', error);
      throw error;
    }
  };
  
  return (
    <Layout>
      <div className="user-profile-container">
        <h1 className="user-profile-title">Your Profile</h1>
        <div className="user-profile-card">
          <form>
            {/* Username Field */}
            <div className="mb-4">
              <label htmlFor="username" className="user-profile-label">Username</label>
              <input
                type="text"
                id="username"
                name="username"
                value={userData.username}
                className="user-profile-input"
                readOnly
              />
            </div>

            {/* Email Field */}
            <div className="mb-4">
              <label htmlFor="email" className="user-profile-label">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={userData.email}
                className="user-profile-input"
                readOnly
              />
            </div>

            {/* Level Field */}
            <div className="mb-4">
              <label htmlFor="level" className="user-profile-label">Level</label>
              <input
                type="text"
                id="level"
                name="level"
                value={userLevel}
                className="user-profile-input"
                readOnly
              />
            </div>
          </form>

          {/* Close Button */}
          <div className="mt-4">
            <button onClick={handleCloseProfile} className="user-profile-button">
              Close
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default UserProfilePage;

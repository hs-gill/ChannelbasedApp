import React, { useState, useContext } from 'react';
import { AuthContext } from './AuthContext';
import './Global.css';
const NewReply = ({ messageId, onPostReply }) => {
  const { userId } = useContext(AuthContext);
  const [reply, setReply] = useState('');
  const [image, setImage] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Create FormData to include the image file, userId, and content
    const formData = new FormData();
    formData.append('content', reply);
    formData.append('userId', userId); // Use 'userId' instead of 'user_id' to match the backend
    if (image) {
      formData.append('image', image);
    }

    // Pass formData to the onPostReply function
    onPostReply(messageId, formData);

    setReply('');
    setImage(null);
  };
  return (
    <form encType="multipart/form-data" onSubmit={handleSubmit} className="new-reply-form">
      <textarea
        className="new-reply-textarea"
        value={reply}
        onChange={(e) => setReply(e.target.value)}
        placeholder="Write your reply..."
        required
        rows="3"
      ></textarea>
      <div className="new-reply-file-input-container">
        <input
          type="file"
          onChange={(e) => setImage(e.target.files[0])}
          className="new-reply-file-input"
        />
        {image && <span className="new-reply-image-name">{image.name}</span>}
      </div>
      <button
        type="submit"
        className="new-reply-submit-button"
      >
        Post Reply
      </button>
    </form>
  );
};

export default NewReply;
import React from 'react';
import MessageItemComponent from './MessageItem';
import './Global.css'; // Assuming Global.css is in the same directory

const MessageList = ({ messages, onDeleteMessage }) => {
    return (
        <div className="message-list-container">
            {messages.length > 0 ? (
                messages.map(message => (
                    <MessageItemComponent 
                        key={message.message_id} 
                        message={message} 
                        onDelete={onDeleteMessage} 
                    />
                ))
            ) : (
                <p className="message-list-empty-message">No messages to display.</p>
            )}
        </div>
    );
};

export default MessageList;

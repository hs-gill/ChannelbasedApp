import React, { useState, useContext } from 'react';
import { AuthContext } from './AuthContext';
import './Global.css'; // Assuming Global.css is in the same directory

const NewMessage = ({ channelId, onPostMessage }) => {
    const { userId } = useContext(AuthContext);
    const [message, setMessage] = useState('');
    const [image, setImage] = useState(null);

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('channelId', channelId);
        formData.append('userId', userId);
        formData.append('content', message);
        if (image) {
            formData.append('image', image);
        }

        onPostMessage(formData);
        setMessage('');
        setImage(null);
    };

    return (
        <form onSubmit={handleSubmit} className="new-message-form">
          <textarea
            className="new-message-textarea"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Write your message..."
            rows="4"
          ></textarea>
          <div className="mt-3">
            <input
              type="file"
              onChange={(e) => setImage(e.target.files[0])}
              className="new-message-file-input"
            />
          </div>
          <button type="submit" className="new-message-submit-button">
            Post Message
          </button>
        </form>
    );
};

export default NewMessage;

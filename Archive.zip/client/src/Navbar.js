import React, { useContext, useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from './AuthContext';
import TopUser from './TopUser';
import './Global.css';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const { isAuthenticated, signOut, userName } = useContext(AuthContext);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const profileMenuRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target)) {
        setShowProfileMenu(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSignOut = () => {
    signOut();
    navigate('/');
  };

  const toggleProfileMenu = () => {
    setShowProfileMenu(!showProfileMenu);
  };

  return (
    <nav className="navbar-container">
      <div className="navbar-links">
        {isAuthenticated && (
          <>
            <Link to="/channels" className="navbar-link">Channels</Link>
            {(userName === 'harpreet' || userName === 'Harpreet') && (
              <Link to="/AllUsers" className="navbar-link">Get All Users</Link>
            )}
          </>
        )}
      </div>
      <div className="navbar-topuser">
        <TopUser />
      </div>
      {isAuthenticated && (
        <div className="navbar-user" ref={profileMenuRef}>
          <button onClick={toggleProfileMenu} className="navbar-user-button">
            <span className="navbar-username">{userName}</span>
            {/* SVG icon remains the same */}
          </button>
          {showProfileMenu && (
  <div className="navbar-user-menu">
    <ul>
      <li className="navbar-user-menu-item">
      <Link to="/userprofile" className="navbar-user-menu-item">
                    Profile
                  </Link>
      </li>
      <li className="navbar-user-menu-item">
        <button onClick={handleSignOut}>Sign Out</button>
      </li>
    </ul>
  </div>
)}

        </div>
      )}
    </nav>
  );
};

export default Navbar;
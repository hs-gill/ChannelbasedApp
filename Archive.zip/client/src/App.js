import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import HomePage from './Homepage';
import SignInComponent from './SignInComponent';
import RegisterComponent from './Register';
import ChannelsPage from './ChannelPage';
import SearchResultsPage from './SerchResult';
import { AuthProvider } from './AuthContext';
import MessagesPage from './MessagesPage';
import UserProfilePage from './UserProfilepage';
import AllUsers from './AllUsers';
function App() {
  return (
    <AuthProvider>
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/signin" element={<SignInComponent />} />
        <Route path="/register" element={<RegisterComponent />} />
        <Route path="/channels" element={<ChannelsPage />} />
        <Route path="/channels/:channelId/messages" element={<MessagesPage />} />
        <Route path="/search" component={SearchResultsPage} />
        <Route path="/Userprofile" element={<UserProfilePage />} />
        <Route path="/AllUsers" element={<AllUsers />} />

        <Route path="*" element={<Navigate to="/" />} /> 
      </Routes>
    </Router>
    </AuthProvider>
  );
}

export default App;


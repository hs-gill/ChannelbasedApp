import React from 'react';
import ReplyItem from './ReplyItem';
import './Global.css'; // Assuming Global.css is in the same directory

const ReplyList = ({ replies, onDeleteReply }) => {
  return (
    <div className="reply-list-container">
      {replies.length > 0 ? (
        replies.map(reply => (
          <ReplyItem key={reply.reply_id} reply={reply} onDeleteReply={onDeleteReply} />
        ))
      ) : (
        <p className="reply-list-empty-message">No replies to show.</p>
      )}
    </div>
  );
};

export default ReplyList;
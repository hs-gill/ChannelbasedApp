import React, { useState, useEffect,useCallback,useContext } from 'react';
import { useParams } from 'react-router-dom';
import MessageListComponent from './MessageList';
import NewMessage from './NewMessage';
import Layout from './Layout';
import SearchBar from './SearchBar';
import SearchResults from './SerchResult';
import { AuthContext } from './AuthContext';
import './Global.css';
const MessagesPage = () => {
    const { userName } = useContext(AuthContext);
    const [messages, setMessages] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchResults, setSearchResults] = useState([]);
    const [searchActive, setSearchActive] = useState(false);
    const [channelDetails, setChannelDetails] = useState({ name: '', description: '' });
    const { channelId } = useParams();

    const fetchChannelDetails = useCallback(async () => {
        try {
            const response = await fetch(`http://localhost:3001/api/channels/${channelId}`);
            if (!response.ok) {
                throw new Error('Failed to fetch channel details');
            }
            const data = await response.json();
            setChannelDetails({ name: data.name, description: data.description });
        } catch (error) {
            console.error('Error fetching channel details:', error);
        }
    }, [channelId]);

    useEffect(() => {
        fetchChannelDetails();
    }, [fetchChannelDetails]);


    const handleReturnToMessages = () => {
        setSearchActive(false);
    };
    const fetchMessages = useCallback(async () => {
        if (searchActive) return;
        setLoading(true);
        try {
            const response = await fetch(`http://localhost:3001/api/messages/channel/${channelId}/`);
            if (!response.ok) {
                throw new Error('Failed to fetch messages');
            }
            const data = await response.json();
            const sortedData = data.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            setMessages(sortedData);
        } catch (error) {
            console.error('Error fetching messages:', error);
        } finally {
            setLoading(false);
        }
    }, [channelId, searchActive]);

    useEffect(() => {
        fetchMessages();
    }, [channelId, fetchMessages]);

    const handlePostMessage = async (formData) => {
        try {
            const response = await fetch(`http://localhost:3001/api/messages/channel/${channelId}/`, {
                method: 'POST',
                body: formData
            });
    
            if (!response.ok) {
                throw new Error('Failed to post message');
            }
    
            // After posting, refetch messages
            fetchMessages();
        } catch (error) {
            console.error('Error posting message:', error);
        }
    };
    
    
    if (loading) {
        return <div>Loading messages...</div>;
    }
    const handleDeleteMessage = (messageId) => {
        setMessages(messages.filter(msg => msg.message_id !== messageId));
    };


    const handleSearch = async (searchTerm, type) => {
        try {
            setSearchActive(true); // Activate search mode
            let url;
            if (type === 'content') {
                url = `http://localhost:3001/api/search/content?q=${encodeURIComponent(searchTerm)}`;
            } else if (type === 'user') {
                url = `http://localhost:3001/api/search/content/user/${encodeURIComponent(searchTerm)}`;
            } else if (type === 'highestLikes') {
                url = `http://localhost:3001/api/search/messages/highestLikes`;
            } else if (type === 'lowestLikes') {
                url = `http://localhost:3001/api/search/messages/lowestLikes`;
            } else {
                console.error('Unknown search type');
                return;
            }
    
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Search failed');
            }
            const data = await response.json();
            setSearchResults(data);
        } catch (error) {
            console.error('Error:', error);
        }
    };
    

    if (loading) {
        return <div>Loading messages...</div>;
    }
    return (
        <Layout>
            <div className="messages-page-container">
                <div className="messages-page-sidebar">
                    <h1>Welcome, {userName}! </h1> 
                    <p>Channel : {channelDetails.name}</p>
                    <p>{channelDetails.description}</p>
                </div>
                <div className="messages-page-main">
                    <SearchBar onSearch={handleSearch} />
                    {searchActive ? (
                        <>
                            <button className="messages-page-button" onClick={handleReturnToMessages}>Return to Messages</button>
                            <SearchResults results={searchResults} />
                        </>
                    ) : (
                        <>
                            <NewMessage channelId={channelId} onPostMessage={handlePostMessage} />
                            <MessageListComponent messages={messages} onDeleteMessage={handleDeleteMessage} />
                        </>
                    )}
                </div>
            </div>
        </Layout>
    );
};

export default MessagesPage;